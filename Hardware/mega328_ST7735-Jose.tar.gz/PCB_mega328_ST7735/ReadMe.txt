Jose Miquel from Spain has made this one-sided printed board 
for a tester with color display (ST7735 controller).
