Adapter m328_m644_AY-AT mod. by boleslaw_43@mikrocontroller.net (09.05.2023)

Base hardware: Component Tester AY-AT, 8 MHz, display ST7735

FUSES for ATmega644p:
L:0xF7
H:0xD9
E:0xFC

LB:0xFF

Adapter pin connections:

ATmega328p	ATmega644p
DIP28: 		TQFN:
1		4
2		44
3		43  (change from 1)
4		3
5		1   (change from 2)
6		40
7		38
8		39
9		7
10		8
11		6
12		11
13		10
14		19
15		20
16		21
17		22
18		23
19		24
20		27
21		29
22		18
23		37
24		36
25		35
26		31
27		34
28		32


Additional connections on TQFN:
                6-39-28-18 (GND)
                5-38-27-17 (VCC)

                ISP:
                1 - MOSI
                2 - MISO
                3 - SCK
                4 - /RESET
                5 - VCC
                6 - GND

ComponentTester firmware ver. 1.49m (mod. 31.05.2023)

B.J.


