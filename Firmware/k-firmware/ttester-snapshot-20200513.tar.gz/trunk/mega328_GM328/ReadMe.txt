This ist the support for a clone on ebay from seller moncss
See: http://www.mikrocontroller.net/topic/345717

FUSES: lfuse=0xF7 hfuse=0xD9 efuse=0xFC
Note: Some newer AvrDude would like to see efuse=0x04

Contrast is a little bit low. Adjust by Menu or set first
EEPROM value to 55=0x37.

