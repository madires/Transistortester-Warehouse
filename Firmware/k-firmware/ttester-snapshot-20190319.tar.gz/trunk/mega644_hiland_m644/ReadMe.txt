This is the configuration for yet another chinese board, which is named
"Original Hiland M644 Transistor Tester LCR Diode Transistor Zener Quartz
Measurement Frequency Counter PWM Square Wave Generator Online ESR" =). It is
built on ATmega644PA and uses ST7565-based LCD display (original part number
is "JLX12864G-378 Ver2.0").

In-system programming connector is located right under the display connector,
labeled as "IDE" on PCB and has following pinout (from left to right):
        1) /Reset
        2) SCK
        3) MISO
        4) MOSI
        5) +5V
        7) GND
