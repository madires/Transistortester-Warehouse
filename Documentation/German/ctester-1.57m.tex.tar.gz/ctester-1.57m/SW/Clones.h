------------------------------------------------------------------------------

             Collection of settings for various tester models

  Please help other users by emailing settings for clones, clone variants
  and other models not listed, and also by reporting bad settings. 

------------------------------------------------------------------------------

Caveat emptor!

Starting around 2022 some tester clones come with an APT32F172K8T6 or LGT8F328
instead of an genuine ATmega, mostly due to the common scarcity of chips and
increased prices ('chipageddon'). These two MCUs aren't supported by the OSHW
firmwares. Also note that the firmware (a modified OSHW firmware) is poorly
adapted to the alternative MCUs, causing some measurements to be sub-par.

We have seen popular clones sold in multiple variants with genuine ATmegas and
alternative MCUs, some even with fake ATmega markings. When buying a clone it
can be hard to identify the MCU. Some hints:
- MCU in DIP is usually an genuine ATmega.
- APT32F172K8T6 has different power pins:
  - 32-LQFP/QFN: 18=Vss, 19=Vdd (ATmega328 32-TQFP: 5=Gnd, 4=Vcc)
- APT32F172K8T6 uses SWD port for ISP:
  - 5 pins: Vdd, Vcc, F_SDAT, F_SCLK, F_RST
- Testers with APT32F172K8T6 often lack a quartz crystal.
- LGT8F328 has slightly different pins:
  - QFP32L: 21=PE2/SWD (ATmega328 32-TQFP: 21=Gnd)
- LGT8F328 uses SWD port for ISP:
  - 5 pins: Gnd, Vcc, SWD, SWC, Reset
- Clone variants with an genuine ATmega are usually about EUR/US$ 5 more
  expensive than the variant with a different MCU.

------------------------------------------------------------------------------

Arduino Nano, Uno or Mega 2560
- Nano/Uno: ATmega 328, 16MHz clock
  Mega 2560: ATmega 2560, 16MHz clock
- Download the Arduino pinout diagram to get the mapping between Arduino and
  ATmega pins.
- The integrated USB2serial adapter makes serial communication simple
  (enable SERIAL_HARDWARE and related options). Don't use the TXD/RXD pins
  for anything else.
- If you want to use Arduino's D13 pin remove the LED circuitry which would
  interfere otherwise.
- only the essential settings are listed

Hardware options:
#define HW_FIXED_SIGNAL_OUTPUT

User interface:
#define UI_AUTOHOLD

Power management:
#define POWER_SWITCH_MANUAL
#define BAT_NONE

Measurement settings and offsets:
#define ADC_LARGE_BUFFER_CAP            /* 100nF cap at AREF */

------------------------------------------------------------------------------

DIY Kit "AY-AT" / GM328A
- ATmega328, 8MHz clock
- ST7735 color LCD module (bit-bang SPI)
- rotary encoder (PD1 & PD3, in parallel with display)
- external 2.5V voltage reference (TL431)
- basic frequency counter with dedicated input (PD4)
- measurement of external voltage up to 45V (PC3)
- settings provided by flywheelz@EEVBlog
- settings for ST7735 semi-compatible display provided by b0hoon4@gmail.com

Hints:
- Some GM328A have an ST7735 semi-compatible display which won't run with the
  standard ST7735 driver. On those modules the level shifter is followed by an
  additional IC (U3, some MCU). In this case use the Semi-ST7735 driver.
 This display doesn't suppport high SPI clock rates.
- The model with a round PCB uses also an ST7735 semi-compatible display. This
  one comes with a level shifter (CD4050) followed by a shift register (
  74HC164) and some MCU on the main PCB. The display doesn't support high
  SPI clock rates. So dont run the ATmega with any clock rate higher than 8MHz.

Hardware Options:
#define HW_ENCODER
#define ENCODER_PULSES   4              /* usually 4 pulses per step */
#define ENCODER_STEPS    20             /* usually 20 detents */
#define HW_REF25
#define HW_ZENER
#define ZENER_UNSWITCHED                /* no boost converter */
#define HW_FREQ_COUNTER_BASIC

LCD module:
#define LCD_ST7735
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_COLOR                       /* color display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTD          /* port data register */
#define LCD_DDR          DDRD           /* port data direction register */
#define LCD_RES          PD0            /* port pin used for /RESX */
#define LCD_CS           PD5            /* port pin used for /CSX (optional) */
#define LCD_DC           PD1            /* port pin used for D/CX */
#define LCD_SCL          PD2            /* port pin used for SCL */
#define LCD_SDA          PD3            /* port pin used for SDA */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       160            /* number of vertical dots */
//#define LCD_OFFSET_X     4              /* enable x offset of 2 or 4 dots */
//#define LCD_OFFSET_Y     2              /* enable y offset of 1 or 2 dots */
#define LCD_FLIP_X                      /* enable horizontal flip */
//#define LCD_FLIP_Y                      /* enable vertical flip */
#define LCD_ROTATE                      /* switch X and Y (rotate by 90 Grad) */
//#define LCD_LATE_ON                     /* turn on LCD after clearing it */
#define FONT_10X16_HF                   /* 10x16 font */
#define SYMBOLS_24X24_HF                /* 24x24 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SDA        /* port pin used for MOSI */

If you prefer that the tester starts with a cleared display uncomment
LCD_LATE_ON.

For the ST7735 semi-compatible display use:
#define LCD_SEMI_ST7735
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_COLOR                       /* color display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTD          /* port data register */
#define LCD_DDR          DDRD           /* port data direction register */
#define LCD_RES          PD0            /* port pin used for /RESX */
#define LCD_CS           PD5            /* port pin used for /CSX (optional) */
#define LCD_DC           PD1            /* port pin used for D/CX */
#define LCD_SCL          PD2            /* port pin used for SCL */
#define LCD_SDA          PD3            /* port pin used for SDA */
#define LCD_DOTS_X       160            /* number of horizontal dots */
#define LCD_DOTS_Y       128            /* number of vertical dots */
#define LCD_LATE_ON                     /* turn on LCD after clearing it */
#define FONT_8X8_HF                     /* 8x8 font */
#define SYMBOLS_30X32_HF                /* 30x32 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SDA        /* port pin used for MOSI */

Rotary Encoder:
#define ENCODER_PORT     PORTD     /* port data register */
#define ENCODER_DDR      DDRD      /* port data direction register */
#define ENCODER_PIN      PIND      /* port input pins register */
#define ENCODER_A        PD3       /* rotary encoder A signal */
#define ENCODER_B        PD1       /* rotary encoder B signal */

Input for the frequency counter is PD4 (T0).


Inductance compensation offsets for 20MHz model
- provided by indman@EEVBlog
- edit the section for high current mode in function MeasureInductor()
  in inductor.c

      #if CPU_FREQ == 20000000
      /* 20 MHz */
      if (Temp < 1500)        /* < 1.5us / < 100uH */
      {
        Offset = -10;
      }
      else if (Temp < 5000)   /* 1.5-5us / 100-330uH */
      {
        Offset = -10; 
      }
      else                    /* > 5us / > 330uH */
      {
        Offset = -30;
      }
      #endif


------------------------------------------------------------------------------

BSide ESR02 (DTU-1701)
- ATmega328, 8MHz clock
- ST7565 display (bit-bang SPI)
- external 2.5V voltage reference (TL431)
- settings provided by indman@EEVblog

Hardware Options:
#define HW_REF25

Power management:
#define BAT_DIVIDER
#define BAT_EXT_UNMONITORED
#define BAT_R1           47000
#define BAT_R2           47000
#define BAT_OFFSET       420

LCD module:
#define LCD_ST7565R                     /* display controller ST7565R */
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTD          /* port data register */
#define LCD_DDR          DDRD           /* port data direction register */
#define LCD_RESET        PD0            /* port pin used for /RES (optional) */
#define LCD_A0           PD1            /* port pin used for A0 */
#define LCD_SCL          PD2            /* port pin used for SCL */
#define LCD_SI           PD3            /* port pin used for SI (LCD's data input) */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       64             /* number of vertical dots */
#define LCD_OFFSET_X                    /* enable x offset of 4 dots */
#define LCD_FLIP_X                      /* enable horizontal flip */
#define LCD_FLIP_Y                      /* enable vertical flip */
#define LCD_START_Y      0              /* start line (0-63) */
#define LCD_CONTRAST     15             /* default contrast (0-63) */
#define FONT_8X8_VF                     /* 8x8 font */
#define SYMBOLS_24X24_VFP               /* 24x24 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SI         /* port pin used for MOSI */

------------------------------------------------------------------------------

Fish8840 TFT
- ATmega328, 8MHz clock
- ST7735 color display (bit-bang SPI)
- external 2.5V voltage reference (TL431)
- settings provided by indman@EEVBlog / bdk100@vrtp.ru
- LCD_DOTS_Y is set to 156 because of an alignment issue between display
  and case. Might need some additional tweaking.

LCD module:
#define LCD_ST7735
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_COLOR                       /* color display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTD          /* port data register */
#define LCD_DDR          DDRD           /* port data direction register */
#define LCD_RES          PD3            /* port pin used for /RESX (optional) */
//#define LCD_CS           PD5            /* port pin used for /CSX (optional) */
#define LCD_DC           PD2            /* port pin used for D/CX */
#define LCD_SCL          PD0            /* port pin used for SCL */
#define LCD_SDA          PD1            /* port pin used for SDA */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       156            /* number of vertical dots */
#define LCD_OFFSET_X                    /* enable x offset of 0 dots */
#define LCD_OFFSET_Y                    /* enable y offset of 0 dots */
#define LCD_FLIP_X                      /* enable horizontal flip */
//#define LCD_FLIP_Y                      /* enable vertical flip */
#define LCD_ROTATE                      /* switch X and Y (rotate by 90 Grad) */
#define LCD_LATE_ON                     /* turn on LCD after clearing it */
#define FONT_10X16_HF                   /* 10x16 font */
#define SYMBOLS_30X32_HF                /* 30x32 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SDA        /* port pin used for MOSI */

Alternative geometry settings from Feliciano@EEVBlog:
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       158            /* number of vertical dots */
#define LCD_OFFSET_X     1               /* enable x offset of 1 dot */
#define LCD_OFFSET_Y     6               /* enable y offset of 6 dots */
#define LCD_FLIP_X                      /* enable horizontal flip */
//#define LCD_FLIP_Y                      /* enable vertical flip */
#define LCD_ROTATE                      /* switch X and Y (rotate by 90 Grad) */


------------------------------------------------------------------------------

GM328
- ATmega328, 8MHz clock
- ST7565 display (bit-bang SPI)
- settings provided by rddube@EEVblog

LCD module:
#define LCD_ST7565R
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTD          /* port data register */
#define LCD_DDR          DDRD           /* port data direction register */
#define LCD_RESET        PD0            /* port pin used for /RES (optional) */
#define LCD_A0           PD1            /* port pin used for A0 */
#define LCD_SCL          PD2            /* port pin used for SCL */
#define LCD_SI           PD3            /* port pin used for SI (LCD's data input) */
#define LCD_CS           PD5            /* port pin used for /CS1 (optional) */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       64             /* number of vertical dots */
#define LCD_START_Y      0              /* start line (0-63) */
#define LCD_CONTRAST     11             /* default contrast (0-63) */
#define FONT_8X8_VF                     /* 8x8 font */
#define SYMBOLS_24X24_VFP               /* 24x24 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SI         /* port pin used for MOSI */

------------------------------------------------------------------------------

Hiland M644
- ATmega 644, 8MHz clock
- ST7565 display (bit-bang SPI)
- rotary encoder (PB7 & PB5, in parallel with display)
- external 2.5V voltage reference (TL431)
- boost converter for Zener check
- extended frequency counter
  (but no input buffer stage for direct frequency measurement) 
- fixed adjustment cap
  (in case of problems replace MLCC with 220nF film cap)
- settings provided by Horst O. (obelix2007@mikrocontroller.net)

Hardware Options:
#define HW_ENCODER
#define ENCODER_PULSES   4              /* 4 */
#define HW_REF25
#define HW_ZENER
#define HW_FREQ_COUNTER_EXT
#define FREQ_COUNTER_PRESCALER     16   /* 16:1 */
#define HW_ADJUST_CAP

Optionally with boost converter driver mod:
#define ZENER_SWITCHED
#define ZENER_BOOST_LOW                 /* low active */

Workarounds:
#define NO_HFE_C_RL                     /* if hFE values too high */

LCD module:
#define LCD_ST7565R
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTB          /* port data register */
#define LCD_DDR          DDRB           /* port data direction register */
#define LCD_RESET        PB4            /* port pin used for /RES (optional) */
//#define LCD_CS           PB2            /* port pin used for /CS1 (optional) */
#define LCD_A0           PB5            /* port pin used for A0 */
#define LCD_SCL          PB6            /* port pin used for SCL */
#define LCD_SI           PB7            /* port pin used for SI (LCD's data input) */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       64             /* number of vertical dots */
//#define LCD_OFFSET_X                  /* enable x offset of 4 dots */
//#define LCD_FLIP_X                      /* enable horizontal flip */
#define LCD_FLIP_Y                      /* enable vertical flip */
#define LCD_START_Y      0              /* start line (0-63) */
#define LCD_CONTRAST     3              /* default contrast (0-63) */
#define FONT_8X8_VF                     /* 8x8 font */
#define SYMBOLS_24X24_VFP               /* 24x24 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SI         /* port pin used for MOSI */

Pinout for test probes (matches defaults):
#define TP_ZENER         PA3       /* test pin with 10:1 voltage divider */
#define TP_REF           PA4       /* test pin with 2.5V reference */
#define TP_BAT           PA5       /* test pin with 4:1 voltage divider */
#define TP_CAP           PA7       /* test pin for self-adjustment cap */

Pinout for probe resistors (matches defaults):
#define R_PORT           PORTD     /* port data register */
#define R_DDR            DDRD      /* port data direction register */
#define R_RL_1           PD2       /* Rl (680R) for test pin #1 */
#define R_RH_1           PD3       /* Rh (470k) for test pin #1 */
#define R_RL_2           PD4       /* Rl (680R) for test pin #2 */
#define R_RH_2           PD5       /* Rh (470k) for test pin #2 */
#define R_RL_3           PD6       /* Rl (680R) for test pin #3 */
#define R_RH_3           PD7       /* Rh (470k) for test pin #3 */

Pinout for power control:
#define POWER_PORT       PORTB     /* port data register */
#define POWER_DDR        DDRB      /* port data direction register */
#define POWER_CTRL       PB1       /* controls power (1: on / 0: off) */

Pinout for test button (matches defaults):
#define BUTTON_PORT      PORTC     /* port data register */
#define BUTTON_DDR       DDRC      /* port data direction register */
#define BUTTON_PIN       PINC      /* port input pins register */
#define TEST_BUTTON      PC7       /* test/start push button (low active) */

Rotary Encoder:
#define ENCODER_PORT     PORTB     /* port data register */
#define ENCODER_DDR      DDRB      /* port data direction register */
#define ENCODER_PIN      PINB      /* port input pins register */
#define ENCODER_A        PB5       /* rotary encoder A signal */
#define ENCODER_B        PB7       /* rotary encoder B signal */

Pinout for extended frequency counter (matches defaults):
#define COUNTER_PORT          PORTB     /* port data register */
#define COUNTER_DDR           DDRB      /* port data direction register */
#define COUNTER_IN            PB0       /* signal input T0 */
#define COUNTER_CTRL_PORT     PORTC     /* port data register */ 
#define COUNTER_CTRL_DDR      DDRC      /* port data direction register */
#define COUNTER_CTRL_DIV      PC0       /* prescaler */
#define COUNTER_CTRL_CH0      PC1       /* channel addr #0 */
#define COUNTER_CTRL_CH1      PC2       /* channel addr #1 */

Pinout for fixed cap for self-adjustment:
#define ADJUST_PORT      PORTC     /* port data register */
#define ADJUST_DDR       DDRC      /* port data direction register */
#define ADJUST_RH        PC6       /* Rh (470k) for fixed cap */

------------------------------------------------------------------------------

M12864 DIY Transistor Tester
- ATmega328, 8MHz clock
- ST7565 display (bit-bang SPI)
- rotary encoder (PD1 & PD3, in parallel with display)
- external 2.5V voltage reference (TL431)

Hardware Options:
#define HW_ENCODER
#define ENCODER_PULSES   4         /* not confirmed yet, could be also 2 */
#define ENCODER_STEPS    24        /* not confirmed yet */
#define HW_REF25

LCD module:
#define LCD_ST7565R
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTD          /* port data register */
#define LCD_DDR          DDRD           /* port data direction register */
#define LCD_RESET        PD0            /* port pin used for /RES */
#define LCD_A0           PD1            /* port pin used for A0 */
#define LCD_SCL          PD2            /* port pin used for SCL */
#define LCD_SI           PD3            /* port pin used for SI (LCD's data input) */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       64             /* number of vertical dots */
//#define LCD_OFFSET_X                    /* enable x offset of 4 dots */
#define LCD_FLIP_Y                      /* enable vertical flip */
#define LCD_START_Y      0              /* start line (0-63) */
#define LCD_CONTRAST     11             /* default contrast (0-63) */
#define FONT_8X8_VF                     /* 8x8 font */
#define SYMBOLS_24X24_VFP               /* 24x24 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SI         /* port pin used for MOSI */

Rotary Encoder:
#define ENCODER_PORT     PORTD     /* port data register */
#define ENCODER_DDR      DDRD      /* port data direction register */
#define ENCODER_PIN      PIND      /* port input pins register */
#define ENCODER_A        PD3       /* rotary encoder A signal */
#define ENCODER_B        PD1       /* rotary encoder B signal */

------------------------------------------------------------------------------

MK-328
- ATmega328, 8MHz clock
- ST7565 display (bit-bang SPI)
- external 2.5V voltage reference (TL431)
- settings provided by brunosso@EEVblog and confirmed by Peeps@EEVblog

Hardware Options:
#define HW_REF25

LCD module:
#define LCD_ST7565R
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTD          /* port data register */
#define LCD_DDR          DDRD           /* port data direction register */
#define LCD_RESET        PD0            /* port pin used for /RES (optional) */
#define LCD_CS           PD5            /* port pin used for /CS1 (optional) */
#define LCD_A0           PD1            /* port pin used for A0 */
#define LCD_SCL          PD2            /* port pin used for SCL */
#define LCD_SI           PD3            /* port pin used for SI (LCD's data input) */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       64             /* number of vertical dots */
#define LCD_START_Y      0              /* start line (0-63) */
#define LCD_CONTRAST     11             /* default contrast (0-63) */
#define FONT_8X8_VF                     /* 8x8 font */
#define SYMBOLS_24X24_VFP               /* 24x24 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SI         /* port pin used for MOSI */

------------------------------------------------------------------------------

T3/T4
- ATmega328, 8MHz clock
- ST7565 display (bit-bang SPI)
- settings provided by tom666@EEVblog
- LCD_RESET could be also PD0

Beware:
- Some newer T4 come with an APT32F172K8T6 (fake Atmel marking) or an LGT8F328
  instead of an ATmega328. These MCUs are not supported.

Hints:
- If the display output is the wrong way around try LCD_FLIP_Y.

LCD module:
#define LCD_ST7565R
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTD          /* port data register */
#define LCD_DDR          DDRD           /* port data direction register */
#define LCD_RESET        PD4            /* port pin used for /RES */
#define LCD_A0           PD3            /* port pin used for A0 */
#define LCD_SCL          PD2            /* port pin used for SCL */
#define LCD_SI           PD1            /* port pin used for SI (LCD's data input) */
#define LCD_CS           PD5            /* port pin used for /CS1 (optional) */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       64             /* number of vertical dots */
#define LCD_START_Y      0              /* start line (0-63) */
#define LCD_CONTRAST     11             /* default contrast (0-63) */
#define FONT_8X8_VF                     /* 8x8 font */
#define SYMBOLS_24X24_VFP               /* 24x24 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SI         /* port pin used for MOSI */

Some T4 variants use a slightly different pin assignment for the display:
#define LCD_RESET        PD0            /* port pin used for /RES */
#define LCD_A0           PD1            /* port pin used for A0 */
#define LCD_SCL          PD2            /* port pin used for SCL */
#define LCD_SI           PD3            /* port pin used for SI (LCD's data input) */
#define LCD_CS           PD5            /* port pin used for /CS1 (optional) */

------------------------------------------------------------------------------

Multifunction Tester LCR-T5
- ATmega328, 8MHz clock
- ST7565 display (bit-bang SPI)
- settings provided by techie@EEVblog

Hardware Options:
#define HW_REF25

LCD module:
#define LCD_ST7565R                     /* display controller ST7565R */
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTD          /* port data register */
#define LCD_DDR          DDRD           /* port data direction register */
#define LCD_RESET        PD2            /* port pin used for /RES (optional) */
#define LCD_CS           PD5            /* port pin used for /CS1 (optional) */
#define LCD_A0           PD1            /* port pin used for A0 */
#define LCD_SCL          PD3            /* port pin used for SCL */
#define LCD_SI           PD4            /* port pin used for SI (data input) */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       64             /* number of vertical dots */
//#define LCD_OFFSET_X                    /* enable x offset of 4 dots */
//#define LCD_FLIP_X                      /* enable horizontal flip */
#define LCD_FLIP_Y                      /* enable vertical flip */
#define LCD_START_Y      0              /* start line (0-63) */
#define LCD_CONTRAST     25             /* default contrast 22 (0-63) */
#define FONT_8X8_VF                     /* 8x8 font */
#define SYMBOLS_24X24_VFP               /* 24x24 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SI         /* port pin used for MOSI */

In case the LCD contrast doesn't work properly edit function LCD_Init() in
ST7565R.c and change

  /* set contrast: resistor ratio 6.5 */
  LCD_Cmd(CMD_V0_RATIO | FLAG_RATIO_65);

to

  /* set contrast: resistor ratio 4.5 */
  LCD_Cmd(CMD_V0_RATIO | FLAG_RATIO_45);

------------------------------------------------------------------------------

Multifunction Tester TC-1 and family (T7, etc) with ATmega324/644, old variants
- ATmega324 (very poor pin assignment), 16MHz clock
  later models may have an ATmega644
- ST7735 color display (bit-bang SPI)
- external 2.5V voltage reference (TL431)
- fixed IR receiver module
- boost converter for Zener check
  (runs all the time, non-standard voltage divider 100k/12k,
  no constant current source, just series resistor)
- fixed adjustment cap
  (in case of problems replace MLCC with 220nF film cap)
- powered by Li-Ion cell 3.7V
- sample testers provided by jellytot@EEVblog and joystik@EEVblog
- initial information provided by indman@EEVblog

Beware:
- Some newer T7 come with an APT32F172K8T6 (fake Atmel marking) instead of
  an ATmega328. This MCU is not supported.

Hints:
- Control MCU U4 (STC15L104W) needs to be replaced with a simple two-transistor
  circuit (TC1-Mod, see source repository for TC1-Mod.kicad.tgz, 5uA standby
  current in total) or reprogrammed with a modified firmware (see
  https://github.com/atar-axis/tc1-u4). The designator can be also U3 (T7 Plus)
  or U5 for newer PCBs.
  A later PCB revision has also a footprint for an alternative MCU (details
  unknown). The hardware mod should still work.
- Set extended fuse byte to 0xfd (brown-out detection).
- If D2 (rectifier diode for Zener test voltage) gets hot replace it with a
  Schottky diode rated for 80V reverse voltage or higher, e.g. SS18.
- Replace C11 and C12 (filter caps for Zener test voltage) with a 10 or 22uF
  low-ESR electrolytic cap rated for 100V or higher because of the MLCC DC
  bias capacitance derating issue.
- Based on the LCD module used you might have to set LCD_FLIP_X instead of
  LCD_FLIP_Y.
- The TC-1 can't provide signal output (PWM/squarewave/etc.) on probe #2. Use
  PD4 (OC1B) as dedicated signal output (add a resistor to limit current) and
  enable HW_FIXED_SIGNAL_OUTPUT in config.h.
- If you like to add a rotary encoder or in/decrease buttons please use
  PB5 (display's D/C) and PB6 (display's SDA).
- You can also get the frequency counter by using PB0 (T0) as input und
  adding a simple input stage.
- In case the tester turns off suddenly after the first probing cycle try to
  enable the workaround option PASSIVE_POWER_CTRL.
- PD0 solder bridge (open: pull-up, shorted: Gnd, unused by m-firmware)

Hardware Options:
#define HW_REF25
#define HW_ZENER
#define ZENER_DIVIDER_CUSTOM
#define ZENER_R1         100000
#define ZENER_R2         12000
#define ZENER_UNSWITCHED                /* boost converter runs all the time */
#define HW_IR_RECEIVER
#define HW_ADJUST_CAP

Optionally:
#define HW_PROBE_ZENER
#define ZENER_VOLTAGE_MIN     1000      /* min. voltage in mV */
#define ZENER_VOLTAGE_MAX     40000     /* max. voltage in mV */

Workarounds (if required):
#define PASSIVE_POWER_CTRL              /* if tester turns off suddenly */

Power management settings:
#define BAT_DIRECT
#define BAT_OFFSET       0
#define BAT_WEAK         3600
#define BAT_LOW          3400

LCD module:
#define LCD_ST7735
#define LCD_COLOR                       /* color graphic display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTB          /* port data register */
#define LCD_DDR          DDRB           /* port data direction register */
#define LCD_RES          PB4            /* port pin used for /RESX (optional) */
//#define LCD_CS           PB?            /* port pin used for /CSX (optional) */
#define LCD_DC           PB5            /* port pin used for D/CX */
#define LCD_SCL          PB7            /* port pin used for SCL */
#define LCD_SDA          PB6            /* port pin used for SDA */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       160            /* number of vertical dots */
#define LCD_OFFSET_X     2              /* enable x offset of 2 or 4 dots */
#define LCD_OFFSET_Y     1              /* enable y offset of 1 or 2 dots */
//#define LCD_FLIP_X                      /* enable horizontal flip */
#define LCD_FLIP_Y                      /* enable vertical flip */
#define LCD_ROTATE                      /* switch X and Y (rotate by 90 Grad) */
#define LCD_LATE_ON                     /* turn on LCD after clearing it */
#define FONT_10X16_HF                   /* 10x16 font */
#define SYMBOLS_30X32_HF                /* 30x32 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SDA        /* port pin used for MOSI */

Pinout for test probes:
#define TP_ZENER         PA4       /* test pin with 10:1 voltage divider */
#define TP_REF           PA3       /* test pin with 2.5V reference */
#define TP_BAT           PA5       /* test pin with 4:1 voltage divider */
#define TP_CAP           PA7       /* test pin for self-adjustment cap */

Pinout for probe resistors:
#define R_PORT           PORTC     /* port data register */
#define R_DDR            DDRC      /* port data direction register */
#define R_RL_1           PC0       /* Rl (680R) for test pin #1 */
#define R_RH_1           PC1       /* Rh (470k) for test pin #1 */
#define R_RL_2           PC2       /* Rl (680R) for test pin #2 */
#define R_RH_2           PC3       /* Rh (470k) for test pin #2 */
#define R_RL_3           PC4       /* Rl (680R) for test pin #3 */
#define R_RH_3           PC5       /* Rh (470k) for test pin #3 */

Pinout for power control:
#define POWER_PORT       PORTD     /* port data register */
#define POWER_DDR        DDRD      /* port data direction register */
#define POWER_CTRL       PD2       /* controls power (1: on / 0: off) */

Pinout for test button:
#define BUTTON_PORT      PORTD     /* port data register */
#define BUTTON_DDR       DDRD      /* port data direction register */
#define BUTTON_PIN       PIND      /* port input pins register */
#define TEST_BUTTON      PD1       /* test/start push button (low active) */

Pinout for fixed IR detector/decoder:
#define IR_PORT          PORTD     /* port data register */
#define IR_DDR           DDRD      /* port data direction register */
#define IR_PIN           PIND      /* port input pins register */
#define IR_DATA          PD3       /* data signal */

Pinout for fixed cap for self-adjustment:
#define ADJUST_PORT      PORTC     /* port data register */
#define ADJUST_DDR       DDRC      /* port data direction register */
#define ADJUST_RH        PC6       /* Rh (470k) for fixed cap */

------------------------------------------------------------------------------

Multifunction Tester TC-1 or T7 with ATmega324, newer variant
- ATmega324, 16MHz clock
- ST7735 color display (bit-bang SPI)
- external 2.5V voltage reference (TL431)
- fixed IR receiver module
- boost converter for Zener check
  (runs all the time, non-standard voltage divider 100k/12k,
  no constant current source, just series resistor)
- fixed adjustment cap
  (in case of problems replace MLCC with 220nF film cap)
- powered by Li-Ion cell 3.7V
- connector for serial TTL interface (5V?)
- settings provided by2hry@EEVblog and Feliciano@EEVblog

Hints:
- Purpose of additional MCU (STC15L104W) is unknown.
- In case the tester turns off suddenly after the first probing cycle try to
  enable the workaround option PASSIVE_POWER_CTRL.

Hardware Options:
#define HW_ZENER
#define ZENER_DIVIDER_CUSTOM
#define ZENER_R1         100000
#define ZENER_R2         12000
#define ZENER_UNSWITCHED                /* boost converter runs all the time */
#define HW_IR_RECEIVER
#define HW_ADJUST_CAP

Optionally:
#define HW_PROBE_ZENER
#define ZENER_VOLTAGE_MIN     500
#define ZENER_VOLTAGE_MAX     25500

Workarounds (if required):
#define PASSIVE_POWER_CTRL              /* if tester turns off suddenly */

Power management settings:
#define BAT_DIRECT
#define BAT_OFFSET       0
#define BAT_WEAK         3600
#define BAT_LOW          3400

LCD module:
#define LCD_ST7735                      /* display controller ST7735 */
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_COLOR                       /* color display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTB          /* port data register */
#define LCD_DDR          DDRB           /* port data direction register */
#define LCD_RES          PB4            /* port pin used for /RESX (optional) */
//#define LCD_CS           PB?            /* port pin used for /CSX (optional) */
#define LCD_DC           PB3            /* port pin used for D/CX */
#define LCD_SCL          PB7            /* port pin used for SCL */
#define LCD_SDA          PB5            /* port pin used for SDA */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       160            /* number of vertical dots */
#define LCD_OFFSET_X     2              /* enable x offset of 2 or 4 dots */
#define LCD_OFFSET_Y     1              /* enable y offset of 1 or 2 dots */
#define LCD_FLIP_X                      /* enable horizontal flip */
//#define LCD_FLIP_Y                      /* enable vertical flip */
//#define LCD_ROTATE                      /* switch X and Y (rotate by 90 Grad) */
#define LCD_LATE_ON                     /* turn on LCD after clearing it */
#define FONT_10X16_HF                   /* 10x16 font */
#define SYMBOLS_30X32_HF                /* 30x32 symbols */
#define SPI_BITBANG                     /* bit-bang SPI */
#define SPI_PORT         LCD_PORT       /* SPI port data register */
#define SPI_DDR          LCD_DDR        /* SPI port data direction register */
#define SPI_SCK          LCD_SCL        /* port pin used for SCK */
#define SPI_MOSI         LCD_SDA        /* port pin used for MOSI */

Hardware SPI should be also possible.

Pinout for test probes:
#define TP_ZENER         PA4       /* test pin with 10:1 voltage divider */
#define TP_REF           PA3       /* test pin for 2.5V reference and relay */
#define TP_BAT           PA5       /* test pin with 4:1 voltage divider */
#define TP_CAP           PA7       /* test pin for self-adjustment cap */

Pinout for probe resistors:
#define R_PORT           PORTC     /* port data register */
#define R_DDR            DDRC      /* port data direction register */
#define R_RL_1           PD0       /* Rl (680R) for test pin #1 */
#define R_RH_1           PD1       /* Rh (470k) for test pin #1 */
#define R_RL_2           PD2       /* Rl (680R) for test pin #2 */
#define R_RH_2           PD3       /* Rh (470k) for test pin #2 */
#define R_RL_3           PD4       /* Rl (680R) for test pin #3 */
#define R_RH_3           PD5       /* Rh (470k) for test pin #3 */

Pinout for power control:
#define POWER_PORT       PORTD     /* port data register */
#define POWER_DDR        DDRD      /* port data direction register */
#define POWER_CTRL       PD7       /* control pin (1: on / 0: off) */

Pinout for test button:
#define BUTTON_PORT      PORTB     /* port data register */
#define BUTTON_DDR       DDRB      /* port data direction register */
#define BUTTON_PIN       PINB      /* port input pins register */
#define TEST_BUTTON      PB2       /* test/start push button (low active) */

Pinout for fixed IR detector/decoder:
#define IR_PORT          PORTD     /* port data register */
#define IR_DDR           DDRD      /* port data direction register */
#define IR_PIN           PIND      /* port input pins register */
#define IR_DATA          PD3       /* data signal */

Pinout for fixed cap for self-adjustment:
#define ADJUST_PORT      PORTC     /* port data register */
#define ADJUST_DDR       DDRC      /* port data direction register */
#define ADJUST_RH        PC6       /* Rh (470k) for fixed cap */

------------------------------------------------------------------------------

Multifunction Tester TC-2 with ATmega324/644
- ATmega324 or 644, 16MHz clock
- ST7735 color display (bit-bang SPI)
- external 2.5V voltage reference (TL431)
- fixed IR receiver module
- boost converter for Zener check
  (runs all the time, non-standard voltage divider 100k/12k,
  no constant current source, just series resistor)
- fixed adjustment cap
  (in case of problems replace MLCC with 220nF film cap)
- powered by Li-Ion cell 3.7V

Hints:
- Quite similar to TC-1, just without the annoying control MCU, i.e. no
  modfication needed to run OSHW firmwares.
- PCB labeled 'T7 PLUS V1.2'

Please use the settings for TC-1 (old variants, see above), but swap the pins
for the test button and and power control:
#define POWER_CTRL       PD1       /* controls power (1: on / 0: off) */
#define TEST_BUTTON      PD2       /* test/start push button (low active) */

------------------------------------------------------------------------------

Multifunction Tester T7 with ATmega328
- ATmega328, 16MHz clock
- ST7735 color display (hardware SPI)
  /RESET line on separate MCU port
- fixed IR receiver module
- boost converter for Zener check
  (runs all the time, about 26V, non-standard voltage divider 100k/12k,
  no constant current source, just series resistor)
- connector for serial TTL interface (J5, 5V)
- settings provided by lhlad@EEVblog (see https://gitlab.com/a11059/t7_328_m)

Hints:
- This model can't provide any signal output (PWM/squarewave/etc.).
- Purpose of additional MCU (STC15L104W) is unknown.
- In case the tester turns off suddenly after the first probing cycle try to
  enable the workaround option PASSIVE_POWER_CTRL.

Hardware Options:
#define HW_ZENER
#define ZENER_DIVIDER_CUSTOM
#define ZENER_R1         100000
#define ZENER_R2         12000
#define ZENER_UNSWITCHED                /* boost converter runs all the time */
#define HW_IR_RECEIVER

Optionally:
#define HW_PROBE_ZENER
#define ZENER_VOLTAGE_MIN     500
#define ZENER_VOLTAGE_MAX     25500

Workarounds (if required):
#define PASSIVE_POWER_CTRL              /* if tester turns off suddenly */

Power management settings:
#define BAT_DIRECT
#define BAT_OFFSET       0
#define BAT_WEAK         3600
#define BAT_LOW          3400

LCD module:
#define LCD_ST7735                      /* display controller ST7735 */
#define LCD_GRAPHIC                     /* graphic display */
#define LCD_COLOR                       /* color display */
#define LCD_SPI                         /* SPI interface */
#define LCD_PORT         PORTB          /* port data register */
#define LCD_DDR          DDRB           /* port data direction register */
#define LCD_RES          PC5            /* port pin used for /RESX (optional) */
#define LCD_RES_PORT     PORTC          /* separate port for /RESX (optional) */
#define LCD_RES_DDR      DDRC           /* separate port for /RESX (optional) */
//#define LCD_CS           PB?            /* port pin used for /CSX (optional) */
#define LCD_DC           PB2            /* port pin used for D/CX */
#define LCD_SCL          PB5            /* port pin used for SCL */
#define LCD_SDA          PB3            /* port pin used for SDA */
#define LCD_DOTS_X       128            /* number of horizontal dots */
#define LCD_DOTS_Y       160            /* number of vertical dots */
#define LCD_OFFSET_X     2              /* enable x offset of 2 or 4 dots */
#define LCD_OFFSET_Y     1              /* enable y offset of 1 or 2 dots */
#define LCD_FLIP_X                      /* enable horizontal flip */
//#define LCD_FLIP_Y                      /* enable vertical flip */
#define LCD_ROTATE                      /* switch X and Y (rotate by 90 Grad) */
//#define LCD_BGR                         /* reverse red and blue color channels */
#define LCD_LATE_ON                     /* turn on LCD after clearing it */
#define FONT_10X16_HF                   /* 10x16 font */
#define SYMBOLS_30X32_HF                /* 30x32 symbols */
#define SPI_HARDWARE                    /* hardware SPI */

Pinout for test probes:
#define TP_ZENER         PC3       /* test pin with 10:1 voltage divider */
#define TP_BAT           PC4       /* test pin with 4:1 voltage divider */

Pinout for probe resistors:
#define R_PORT           PORTD     /* port data register */
#define R_DDR            DDRD      /* port data direction register */
#define R_RL_1           PD2       /* Rl (680R) for test pin #1 */
#define R_RH_1           PD3       /* Rh (470k) for test pin #1 */
#define R_RL_2           PD4       /* Rl (680R) for test pin #2 */
#define R_RH_2           PD5       /* Rh (470k) for test pin #2 */
#define R_RL_3           PD6       /* Rl (680R) for test pin #3 */
#define R_RH_3           PD7       /* Rh (470k) for test pin #3 */

Pinout for power control:
#define POWER_PORT       PORTB     /* port data register */
#define POWER_DDR        DDRB      /* port data direction register */
#define POWER_CTRL       PB1       /* control pin (1: on / 0: off) */

Pinout for test button:
#define BUTTON_PORT      PORTB     /* port data register */
#define BUTTON_DDR       DDRB      /* port data direction register */
#define BUTTON_PIN       PINB      /* port input pins register */
#define TEST_BUTTON      PB4       /* test/start push button (low active) */

Pinout for fixed IR detector/decoder:
#define IR_PORT          PORTB     /* port data register */
#define IR_DDR           DDRB      /* port data direction register */
#define IR_PIN           PINB      /* port input pins register */
#define IR_DATA          PB0       /* data signal */

------------------------------------------------------------------------------
T4 variants use Rotary Encoder
Misc settings:
#define HW_ENCODER
#define ENCODER_PULSES   4
#define ENCODER_STEPS    24
#define HW_REF25
#define UREF_25           2495
#define HW_FREQ_COUNTER_BASIC
#define HW_EVENT_COUNTER
#define EVENT_COUNTER_TRIGGER_OUT
#define SW_PWM_SIMPLE
#define SW_INDUCTOR
#define SW_ESR
#define SW_DS18B20
#define SW_REVERSE_HFE
#define SW_DHTXX
#define UI_COMMA
#define UI_AUTOHOLD
#define UI_KEY_HINTS
#define POWER_OFF_TIMEOUT     30
#define SW_POWER_OFF
#define UI_ROUND_DS18B20
#define ONEWIRE_PROBES 
------------------------------------------------------------------------------
